Place web-optimized images here or serve from /assets/img in project root via dev server config if desired.


