// Restaurant Dashboard Pages - centralized exports
export { default as RestaurantDashboard } from './RestaurantDashboard';
export { default as SweetDreamsDashboard } from './SweetDreamsDashboard';
export { default as AlohaKitchenDashboard } from './AlohaKitchenDashboard';

