// This file is not used - AdminApp is imported in main.tsx
// Keeping for reference but it's not the entry point
export {};